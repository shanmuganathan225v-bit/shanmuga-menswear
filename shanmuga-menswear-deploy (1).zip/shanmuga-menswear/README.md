# Shanmuga Mens Wear — Website

Premium men's fashion store for Tamil Nadu.

## Files
- `index.html` — Main storefront
- `product.html` — Product detail page
- `login.html` — Customer login
- `admin.html` — Admin panel (login: admin / admin123)
- `images/` — Product images folder

---

## 🚀 Deploy to GitHub Pages (FREE — Recommended)

### Step 1 — Create GitHub Account
1. Go to [github.com](https://github.com) → Sign Up (free)
2. Verify your email

### Step 2 — Create Repository
1. Click **"New"** (green button)
2. Repository name: `shanmuga-menswear` (or any name)
3. Set to **Public**
4. Click **"Create repository"**

### Step 3 — Upload Your Files
1. Click **"uploading an existing file"** link
2. Drag and drop ALL these files:
   - index.html
   - product.html
   - login.html
   - admin.html
   - 404.html
   - _redirects
   - render.yaml
   - README.md
   - images/ folder (with all your photos)
3. Scroll down → Click **"Commit changes"**

### Step 4 — Enable GitHub Pages
1. Go to **Settings** tab (top of repository)
2. Left sidebar → click **"Pages"**
3. Source: **"Deploy from a branch"**
4. Branch: **main** → Folder: **/ (root)**
5. Click **Save**
6. Wait 2–3 minutes

### ✅ Your site will be live at:
```
https://YOUR-USERNAME.github.io/shanmuga-menswear/
```

---

## 🚀 Deploy to Render (FREE — Alternative)

### Step 1 — Create Render Account
1. Go to [render.com](https://render.com) → Sign Up with GitHub

### Step 2 — New Static Site
1. Click **"New +"** → **"Static Site"**
2. Connect your GitHub repository
3. Settings:
   - **Name:** shanmuga-menswear
   - **Build Command:** (leave empty)
   - **Publish Directory:** `.`
4. Click **"Create Static Site"**

### ✅ Your site will be live at:
```
https://shanmuga-menswear.onrender.com
```

---

## 🌐 Custom Domain Setup

### For GitHub Pages:
1. Buy domain from **GoDaddy**, **Namecheap**, or **Google Domains**
   - Recommended: `shanmugamenswear.com` (~₹800/year)

2. **In your domain registrar** → DNS Settings, add:
   ```
   Type: A    Host: @    Value: 185.199.108.153
   Type: A    Host: @    Value: 185.199.109.153
   Type: A    Host: @    Value: 185.199.110.153
   Type: A    Host: @    Value: 185.199.111.153
   Type: CNAME  Host: www  Value: YOUR-USERNAME.github.io
   ```

3. **In GitHub** → Repository → Settings → Pages:
   - Custom domain: `shanmugamenswear.com`
   - ✅ Check "Enforce HTTPS"
   - Wait 10–15 minutes for DNS to propagate

### For Render:
1. Go to your Render site dashboard
2. Click **"Custom Domain"** → Add your domain
3. Render shows you the CNAME record to add in your DNS:
   ```
   Type: CNAME  Host: @  Value: YOUR-SITE.onrender.com
   ```
4. Add this in your domain registrar's DNS settings

---

## 📁 Adding Product Images

Place your images in the `images/` folder:
- `images/hero.jpg` — Hero banner (1920×1080)
- `images/shirts.jpg` — Shirts category (260×380)
- `images/pants.jpg` — Pants category (260×380)
- `images/tshirts.jpg` — T-Shirts category (260×380)

Product photos are uploaded via the **Admin Panel** using image URLs or local uploads.

---

## 🔑 Admin Panel

Access: `yoursite.com/admin.html`
- Username: `admin`
- Password: `admin123`

**Change the password** after first login via Security → Change Password.

---

## 📱 WhatsApp Number
The store is configured for: **+91 94426 89858**
To change: Search for `919442689858` in all HTML files and replace.
